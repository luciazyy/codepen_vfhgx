A Pen created at CodePen.io. You can find this one at http://codepen.io/jon-walstedt/pen/vfhgx.

 Dimmer switch based on http://dribbble.com/shots/910235-Light-Dimmer-Switch